package models

case class Post(uid: String, title: String, body: String, date: String, user: User)
