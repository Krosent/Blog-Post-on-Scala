package models

case class Comment(uid: String, body: String, author: User, post: Post, date: String)
