package models

case class User(uid: String, username: String, password: String)
