package models

object ReactionType extends Enumeration {
  type ReactionType = Value
  val Like = "Like"
  val Dislike = "Dislike"
}

