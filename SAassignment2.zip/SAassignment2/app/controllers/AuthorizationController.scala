package controllers

import javax.inject.Inject
import play.api.mvc.{AbstractController, ControllerComponents}
import storage.DBEmulator

class AuthorizationController  @Inject()(cc: ControllerComponents) extends AbstractController(cc) {

  /**
   * Create an Action to render an HTML page with a welcome message.
   * The configuration in the `routes` file means that this method
   * will be called when the application receives a `GET` request with
   * a path of `/`.
   */
  def index = Action { implicit request =>
    Ok(views.html.login(""))
  }

  def login() = Action { implicit request =>
    var login = ""
    var password = ""
    val postVals = request.body.asFormUrlEncoded
    postVals.map { args =>
      login = args("InputLogin").head
      password = args("InputPassword").head
    }

    if(DBEmulator.users.exists(usr => usr.username == login && usr.password == password)) {
      Redirect("/").withSession("login" -> login, "password" -> password)
    } else {
      Redirect("/login").flashing("failure" -> "Could not login. Wrong login or password. Please try again!")
    }
    }

  def logout() = Action { implicit request =>
    Redirect("/").withSession(request.session - "login")
  }
  }
