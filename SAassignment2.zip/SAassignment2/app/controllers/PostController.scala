package controllers

import java.util.Calendar
import java.util.UUID.randomUUID

import javax.inject.Inject
import models.{Comment, Post, ReactionType, User}
import play.api.mvc.{AbstractController, ControllerComponents}
import storage.DBEmulator

class PostController @Inject()(cc: ControllerComponents) extends AbstractController(cc) {

  import java.text.SimpleDateFormat

  val timePattern = "yyyy-MM-dd"
  val simpleDateFormat = new SimpleDateFormat(timePattern)

  def index(id: String) = Action { implicit request =>
    Ok(views.html.post(id))
  }

  def create() = Action { implicit request =>
    val postVals = request.body.asFormUrlEncoded
    var title = ""
    var date = ""
    var textBody = ""
    val username = request.session.get("login")
    postVals.map { args =>
      title = args("InputTitle").head
      textBody = args("InputText").head
      date = args("InputDate").head
    }

    if (username.nonEmpty) {
      val userModel = DBEmulator.users.find(usr => usr.username == username.get).get
      val post = Post(randomUUID().toString, title, textBody, date, userModel)
      DBEmulator.posts += post
      Redirect("/").flashing("success" -> "Post has been added!")
    } else {
      Redirect("/").flashing("failure" -> "Could not add post. You are not authorized")
    }
  }

  def newPostViewRender() = Action { implicit request =>
    Ok(views.html.newPost())
  }

  def comment(postId: String) = Action { implicit request =>
    val postVals = request.body.asFormUrlEncoded
    var comment = ""
    val username = request.session.get("login")
    postVals.map { args =>
      comment = args("InputComment").head
    }

    if (username.nonEmpty) {
      val timePattern = "dd-MM-yyyy"
      import java.text.SimpleDateFormat
      val simpleDateFormat = new SimpleDateFormat(timePattern)
      val today = Calendar.getInstance.getTime
      val formattedDate = simpleDateFormat.format(today)

      val userModel = DBEmulator.users.find(usr => usr.username == username.get).get
      val currentPost: Post = DBEmulator.posts.find(post => post.uid.contains(postId)).get
      val cmt = Comment(randomUUID().toString, comment, userModel, currentPost, formattedDate)
      DBEmulator.comments += cmt
      Redirect(s"/post/${postId}").flashing("success" -> "The comment has been added")
    } else {
      //Ok("Not authorized")
      Redirect(s"/post/${postId}").flashing("failure" -> "Could not add comment. You are not authorized")
    }
  }

  def like(postId: String) = Action { implicit request =>
    val username = request.session.get("login")
    if (username.nonEmpty) {
      val userModel = getUserModel(username)
      val currentPost: Post = DBEmulator.posts.find(post => post.uid.contains(postId)).get

      if (DBEmulator.reactions.exists(e => e._1 == userModel && e._2 == currentPost && e._3 == ReactionType.Like)) {
        DBEmulator.reactions -= Tuple3(userModel, currentPost, ReactionType.Like)
        Redirect("/")
      } else if (DBEmulator.reactions.exists(e => e._1 == userModel && e._2 == currentPost && e._3 == ReactionType.Dislike)) {
        DBEmulator.reactions -= Tuple3(userModel, currentPost, ReactionType.Dislike)
        DBEmulator.reactions += Tuple3(userModel, currentPost, ReactionType.Like)
        Redirect("/")
      }
      else {
        val like = Tuple3(userModel, currentPost, ReactionType.Like)
        DBEmulator.reactions += like
        Redirect("/")
      }
    } else {
      Redirect("/").flashing("failure" -> "Could not add like. You are not authorized to do that")
    }
  }

  def dislike(postId: String) = Action { implicit request =>
    val username = request.session.get("login")
    if (username.nonEmpty) {
      val userModel = getUserModel(username)
      val currentPost: Post = DBEmulator.posts.find(post => post.uid.contains(postId)).get

      if (DBEmulator.reactions.exists(e => e._1 == userModel && e._2 == currentPost && e._3 == ReactionType.Dislike)) {
        DBEmulator.reactions -= Tuple3(userModel, currentPost, ReactionType.Dislike)
        Redirect("/")
      } else if (DBEmulator.reactions.exists(e => e._1 == userModel && e._2 == currentPost && e._3 == ReactionType.Like)) {
        DBEmulator.reactions -= Tuple3(userModel, currentPost, ReactionType.Like)
        DBEmulator.reactions += Tuple3(userModel, currentPost, ReactionType.Dislike)
        Redirect("/")
      }
      else {
        val like = Tuple3(userModel, currentPost, ReactionType.Dislike)
        DBEmulator.reactions += like
        Redirect("/")
      }
    } else {
      Redirect("/").flashing("failure" -> "Could not add dislike. You are not authorized to do that")
    }
  }

  def sortByLikes() = Action { implicit request =>
    val posts = DBEmulator.posts.sortBy(post => {
      val likes = DBEmulator.reactions.count(x => x._3 == ReactionType.Like && x._2 == post)
      val dislikes = DBEmulator.reactions.count(x => x._3 == ReactionType.Dislike && x._2 == post)
      likes - dislikes
    }).reverse
    Ok(views.html.index(posts))
  }

  def sortByDate() = Action { implicit request =>
    Ok(views.html.index(DBEmulator.posts.sortBy(post => simpleDateFormat.parse(post.date).getTime).reverse))
  }

  def getUserModel(username: Option[String]): User = {
    DBEmulator.users.find(usr => usr.username == username.get).get
  }

}