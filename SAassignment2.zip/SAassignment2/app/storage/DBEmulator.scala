package storage

import models.{Comment, Post, ReactionType, User}

import scala.collection.mutable.ListBuffer
import java.util.UUID.randomUUID

object DBEmulator {

  var users: ListBuffer[User] = ListBuffer.empty
  var posts: ListBuffer[Post] = ListBuffer.empty
  var reactions: ListBuffer[(User, Post, String)] = ListBuffer.empty
  var comments: ListBuffer[Comment] = ListBuffer.empty

  // Hardcoded users are here
  val user1 = User(randomUUID().toString, "artyom", "12345")
  val user2 = User(randomUUID().toString, "admin", "admin") // Not so secure, right? :)
  users += user1
  users += user2

  val post1 = Post(randomUUID().toString, "First Post", "Lorem Ipsum is simply dummy text of the printing and typesetting industry. " +
    "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer " +
    "took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries," +
    " but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s " +
    "with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing " +
    "software like Aldus PageMaker including versions of Lorem Ipsum.", "2015-12-02", user1)
  val post2 = Post(randomUUID().toString, "Second Post", "Perhaps, Lorem ipsum may be here also!!!", "2019-12-04", user1)
  val post3 = Post(randomUUID().toString, "Third Post", "I want to post something as well!!!!!", "2018-12-06", user2)

  reactions += Tuple3(user1, post1, ReactionType.Like)

  posts += (post1, post2, post3)

  val comment1 = Comment(randomUUID().toString, "comment example", user1, post1, "2020-01-01")
  comments += comment1

}
